﻿import type { DayNumber, RuinDefinition, RuinType } from "./types";

export const TRIBE_COUNT = 12;

export const DEFAULT_TRIBE_COLOR_SCHEMES = [
  { primary: "#b91c1c", secondary: "#f8fafc" }, // MF69 - red / white
  { primary: "#0f766e", secondary: "#99f6e4" }, // teal / mint
  { primary: "#1e88e5", secondary: "#80d8ff" },
  { primary: "#43a047", secondary: "#d4e157" },
  { primary: "#8e24aa", secondary: "#fdd835" },
  { primary: "#00897b", secondary: "#80deea" },
  { primary: "#6d4c41", secondary: "#ffcc80" },
  { primary: "#d81b60", secondary: "#f8bbd0" },
  { primary: "#3949ab", secondary: "#ff8a65" },
  { primary: "#7cb342", secondary: "#fff59d" },
  { primary: "#546e7a", secondary: "#ffab91" },
  { primary: "#5e35b1", secondary: "#a5d6a7" },
];

export const RUIN_DEFINITIONS: RuinDefinition[] = [
  ...Array.from({ length: 10 }, (_, index) => ({
    id: `B${index + 1}`,
    name: `B${index + 1}`,
    type: "bastion" as const,
  })),
  ...Array.from({ length: 6 }, (_, index) => ({
    id: `V${index + 1}`,
    name: `V${index + 1}`,
    type: "valkyrie" as const,
  })),
  {
    id: "T1",
    name: "T1",
    type: "temple" as const,
  },
];

export const RUIN_FIRST_CAPTURE_POINTS: Record<RuinType, number> = {
  bastion: 5000,
  valkyrie: 10000,
  temple: 30000,
};

export const RUIN_MINUTE_RATES: Record<RuinType, Record<DayNumber, number>> = {
  bastion: {
    1: 10,
    2: 20,
    3: 30,
  },
  valkyrie: {
    1: 20,
    2: 40,
    3: 60,
  },
  temple: {
    1: 60,
    2: 120,
    3: 180,
  },
};
